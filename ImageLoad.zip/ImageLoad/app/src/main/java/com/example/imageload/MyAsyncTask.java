package com.example.imageload;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MyAsyncTask extends AsyncTask<String, Void, Bitmap> {

    MainActivity cnt;
    ProgressDialog dialog;

    public MyAsyncTask(MainActivity mainActivity) {

        cnt=mainActivity;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog=new ProgressDialog(cnt);
        dialog.setTitle("download");

        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.show();

    }

    @Override
    protected Bitmap doInBackground(String... strings) {

        String myurl="https://image.shutterstock.com/image-photo/kiev-ukraine-may-26-2015-260nw-283385381.jpg";

        try {
            URL url=new URL(myurl);
            HttpURLConnection connection= (HttpURLConnection) url.openConnection();
            connection.connect();

            InputStream in=connection.getInputStream();
            Bitmap bitmap= BitmapFactory.decodeStream(in);
            return bitmap;


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return null;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        dialog.dismiss();

        cnt.img.setImageBitmap(bitmap);
    }
}
